<?php

namespace App\Http\Controllers;

use App\Models\registrados;
use Illuminate\Http\Request;

class RegistradosController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(registrados $registrados)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(registrados $registrados)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, registrados $registrados)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(registrados $registrados)
    {
        //
    }
}
