import './bootstrap';


import Swal from 'sweetalert2'
window.Swal = Swal;